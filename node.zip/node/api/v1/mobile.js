// Author: Howard Chang
'use strict' ;
const express = require('express') ;
const mobile = express() ;
//var abc = require("server").abc;
function setup(app) {
    app.use("/api/app/v1/mobile", mobile);

    // get app
    mobile.get("/:os/:did", function (req, res) {
        var resp = {};
        var data = {};
        var data1 = {};
        var compatibleApps = [];
        var compatibleApps1 = [];
        var app1 = {}, app2 = {};
        var error = {};
        var model = {};
        var models = [];
        let filePath = "C:\\bw_exe\\node\\lines.txt";
        var fs = require("fs");
        var cba = abc;
        //try {
        //     var data = fs.readFileSync('lines.txt', 'utf8');
        //     console.log(data);
        // } catch (e) {
        //      console.log('Error:', e.stack);
        //   }
        var data1 = fs.readFileSync('lines.txt', 'utf8');

        var array = data1.toString().split('\n');

        //for (var ii in array)
        for (var i = 0; i < array.length; i++) {
            var prs = array[i].split(',');
            if (prs.length < 4)
                continue;
            var model1 = {};
            model1.md = prs[0];
            model1.app_id = prs[1];
            model1.ios_lnk = prs[2];
            model1.andr_lnk = prs[3];
            compatibleApps.push(model1);

        }
        // use the array




        var dv = req.params["did"];
        if (dv.indexOf("lhv", 0) == 0) {
            for (var i = 0; i < compatibleApps.length; i++) {
                if (compatibleApps[i].md.indexOf("lhv2008", 0) == 0)
                    compatibleApps1.push(compatibleApps[i]);
}

    data.compatibleApps = compatibleApps1;
    resp.data = data;
}

if (dv.indexOf("lnk", 0) == 0) {
    for (var i = 0; i < compatibleApps.length; i++) {
        if (compatibleApps[i].md.indexOf("LNK7108A", 0) == 0)
            compatibleApps1.push(compatibleApps[i]);
    }
        data.compatibleApps = compatibleApps1;
        resp.data = data;
    }

    if (dv.indexOf("fxc", 0) == 0) {
        for (var i = 0; i < compatibleApps.length; i++) {
            if (compatibleApps[i].md.indexOf("fxc", 0) == 0)
                compatibleApps1.push(compatibleApps[i]);
        }
            data.compatibleApps = compatibleApps1;
            resp.data = data;
        }

           // data.model = models[0].md;
        //data.model = "LHV2008";
        if (dv.indexOf("xxx", 0) == 0) {
            if ("ios" == req.params["os"]) {
                app1.appName = "Lorex Secure";
                app1.appId = "com.lorex.consumer.secure";
                app1.appLink = "https://itunes.apple.com/ca/app/lorex-secure/id1220180698?mt=8";

                app2.appName = "Lorex Home";
                app2.appId = "com.lorex.consumer.home";
                app2.appLink = "https://itunes.apple.com/ca/app/lorex-home/id1342829120?mt=8";
            }
            else if ("android" == req.params["os"]) {
                app1.appName = "Lorex Secure";
                app1.appId = "com.lorex.consumer.secure";
                app1.appLink = "https://play.google.com/store/apps/details?id=com.lorex.consumer.secure&hl=en_CA";

                app2.appName = "Lorex Home";
                app2.appId = "com.mm.android.lorex";
                app2.appLink = "https://play.google.com/store/apps/details?id=com.mm.android.lorex&hl=en_CA";
            }
            else {
                return res.end(`not supported os: ${req.params["os"]}`);
            }

            compatibleApps.push(app1);
            compatibleApps.push(app2);

            data.compatibleApps = compatibleApps;
            resp.data = data;
        }

        if (typeof data.compatibleApps == "undefined") {
            error.code = "404";
            error.desc ="key not found"
            data.compatibleApps = compatibleApps;
            resp.error = error;
        }
       

        res.json(resp).end() ;
    }) ;
}

exports.setup = setup ;