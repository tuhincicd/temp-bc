// Author: Howard Chang
var server = require("./server") ;
//http://localhost:9091/api/app/v1/mobile/ios/fxc00001
server.start() ;
