const Config =
{
    Server: {},
    Cors: {}
}

Config.Server.serviceName = "App service" ;
Config.Server.servicePort = 9091 ;

Config.Cors.originsWhiteList = ['http://localhost:4200'] ;


exports.Config = Config ;