// Author: Howard Chang
'use strict' ;
const cfg = require('./config/service_config').Config ;
const express = require('express') ;
const app = express() ;
const cors = require('cors') ;

const v1_mobile = require("./api/v1/mobile") ;
global.abc = "999";
function enableCors()
{
    var originsWhitelist = cfg.Cors.originsWhiteList ;
    var corsOptions =
    {
        origin: function(origin, callback)
        {
              var isWhitelisted = originsWhitelist.indexOf(origin) !== -1 ;
              callback(null, isWhitelisted) ;
        },
        credentials: true
    }
    app.use(cors(corsOptions)) ;
}

function start()
{
    app.use( express.json() ) ;                         // to support JSON-encoded bodies
    app.use( express.urlencoded({extended: true}) ) ;   // to support URL-encoded bodies
    //abc = "7777";
    enableCors() ;
    v1_mobile.setup(app) ;

    // Endpoint for health check
    app.get("/healthcheck", function(req, res)
    {
        res.end("OK") ;
    }) ;

    app.all("*", function(req, res)
    {
        res.end("Oh oh, wrong URL...") ;
    }) ;

    app.get("/", function(req, res)
    {
        res.end() ;
    }) ;

    // HTTP
    var srv = app.listen(cfg.Server.servicePort, function ()
    {
        var _host = srv.address().address ;
        var _port = srv.address().port ;
        console.log(`${cfg.Server.serviceName} is running on http://${_host}:${_port}`) ;
    }) ;
}


exports.start = start ;
exports.abc = abc;