const Config =
{
    Server: {},
    DahauCloud: {},
    Database: {},
    Cors: {},
    Jwt: {},
    Redis: {}
}

Config.Server.serviceName = "Cloud service" ;
Config.Server.servicePort = 9090 ;
Config.Server.version = "v0.0.3(20181119)" ;

Config.DahauCloud.username = "LOREXPROXYSERVICE" ;
Config.DahauCloud.password = "99EB08EE5C7242EFB63C7F7013E1885B" ;

Config.Cors.originsWhiteList = ['http://localhost:4200'] ;

Config.Database.config =
{
    connectionLimit: 10,
    host: "54.158.115.123",
    port: 3306,
    user: "root" ,
    password: "password",
    database: "skynet"
}
Config.Database.tableNameForRequests = "cloud_requests" ;

Config.Jwt.secret = "1c52495c358144f5a69d5e4a7b17322a" ;
Config.Jwt.expiration = 86400000 ; // in ms. 1 day

Config.Redis.host = "54.158.115.123" ;
Config.Redis.port = 6379 ;

exports.Config = Config ;