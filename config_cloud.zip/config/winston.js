const appRoot = require('app-root-path') ;
const winston = require('winston') ;
const util = require('util') ;
const moment = require('moment') ;
const MESSAGE = Symbol.for('message') ;

const options =
{
    file:
    {
        level: 'info',
        filename: `${appRoot}/logs/cloud_service.log`,
        handleExceptions: true,
        json: true,
        maxsize: 5242880, // 5MB
        maxFiles: 5,
        colorize: false,
        timestamp: true
    },
    console:
    {
        level: 'debug',
        handleExceptions: true,
        json: false,
        colorize: true,
        timestamp: true
    }
} ;

var logger = winston.createLogger(
{
    format: winston.format.combine(
        winston.format(function(info, opts) {
            prefix = util.format('[%s] [%s]', moment().format('YYYY-MM-DD hh:mm:ss').trim(), info.level.toUpperCase());
            if (info.splat) {
                info.message = util.format('%s %s', prefix, util.format(info.message, ...info.splat));
            } else {
                info.message = util.format('%s %s', prefix, info.message);
            }
            return info;
        })(),
        winston.format(function(info)
        {
            info[MESSAGE] = info.message ;
            return info;
        })()
        // winston.format.timestamp(),
        // winston.format.json()
    ),
    transports: [
      new winston.transports.File(options.file),
      new winston.transports.Console(options.console)
    ],
    exitOnError: false, // do not exit on handled exceptions
}) ;

exports.logger = logger ;